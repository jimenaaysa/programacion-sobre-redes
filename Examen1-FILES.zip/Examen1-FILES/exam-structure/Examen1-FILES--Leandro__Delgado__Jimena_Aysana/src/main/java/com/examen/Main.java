package com.examen;

/**
 * Punto de entrada principal del programa.
 * <p>
 * Orquesta la ejecucion:
 * 1. Inicializa LogManager
 * 2. Crea un Estandarizador y estandariza juegos.dat
 * 3. Crea un GestorPartidas
 * 4. Inicia el menu interactivo
 */
public class Main {

    public static void main(String[] args) {
        // COMPLETAR: inicializar LogManager
        // COMPLETAR: crear Estandarizador y estandarizar "juegos.dat"
    	Estandarizador est = new Estandarizador();
    	est.estandarizar("C:\\Users\\Redes-04\\Desktop\\Examen1-FILES\\exam-structure\\Examen1-FILES--Leandro__Delgado__Jimena_Aysana\\juegos.dat");
        // COMPLETAR: crear GestorPartidas y Menu
        // COMPLETAR: iniciar el menu
    }
}
